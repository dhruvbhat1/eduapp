import * as React from 'react';
import 'react-native-gesture-handler';
// import { StyleSheet, Text, View, TextInput, Button, ScrollView, FlatList,Image,TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Onboard1 from './Components/Onboard1';
import Onboard2 from './Components/Onboard2';
import Onboard3 from './Components/Onboard3';
import login from './Components/login';
import Otp from './Components/Otp';
import Profilem from './Components/Profilem';
import Option from './Components/Option';
import Teachers from './Components/Teachers';
import Firstintropage from './Components/Firstintropage';
import ClassTest from './Components/ClassTest';
import Video from './Components/VideoPage';
import Assignment from './Components/Assignment';
import Notes from './Components/Notespage';
import Test1 from './Components/Test1';
import Test2 from './Components/Test2';
import MainTest from './Components/MainTest';


const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="login">
        <Stack.Screen name="Onboard1" component={Onboard1} />
        <Stack.Screen name="Onboard2" component={Onboard2} />
        <Stack.Screen name="Onboard3" component={Onboard3} />
        <Stack.Screen name="Details" component={Option} />
        <Stack.Screen name="login" component={login} />
        <Stack.Screen name="Otp" component={Otp}/>
        <Stack.Screen name="Profilem" component={Profilem}/> 
        <Stack.Screen name="Firstintropage" component={Firstintropage}/> 
        <Stack.Screen name="Teachers" component={Teachers}/> 
        <Stack.Screen name="ClassTest" component={ClassTest}/> 
        <Stack.Screen name="Video" component={Video}/> 
        <Stack.Screen name="Assignment" component={Assignment}/> 
        <Stack.Screen name="Notes" component={Notes}/> 
        <Stack.Screen name="Test1" component={Test1}/> 
        <Stack.Screen name="Test2" component={Test2}/> 
        <Stack.Screen name="MainTest" component={MainTest}/> 
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;