import React from "react";
import { View, Text, StyleSheet, StatusBar, ImageBackground, ScrollView,Button, TouchableOpacity, SafeAreaView,Dimensions,Image} from "react-native";

import { Entypo , Octicons, Ionicons} from '@expo/vector-icons'; 




import upper from '../images/upper.jpeg';

import intro1 from '../images/intro1.jpeg';
import architecture from '../images/architecture.jpeg';
import markov from '../images/markov.jpeg';
import simulator from '../images/simulator.jpeg';
import standard from '../images/standard.jpeg';
import network from '../images/network.jpeg';
import linklayer from '../images/linklayer.jpeg';
import transport from '../images/transport.jpeg';

import Constants from 'expo-constants';




const stylePageWidth = { width:Dimensions.get('window').width };

export default class Notespage extends React.Component{
  

  render(){
    return(
     
        <ImageBackground source={upper} style={styles.backgroundContainer}>
        <View style={styles.container}>
        
        <View style={styles.header}>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu1}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu2}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu3}/>
        <Octicons name="settings" size={24} color="#fff" style={styles.adjust}/>
        <Text style={styles.uppertext}>COMPUTER COMMUNICATION{'\n'}NETWORKS</Text>
        <Text style={styles.uppertext1}>Prof.Kevin Narohna</Text>
 

        </View>


        <View style={styles.footer}>
        <View className="col-3" style={{top:-120,right:25,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Video')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Video</Text>
           </TouchableOpacity> 
</View> 
    {/* //#2a9df4 */}

<View className="col-3"  style={{top:-150,left:50,width:70}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Notes')} 
           style={{backgroundColor: '#2a9df4',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"white"}}>Notes</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-180,left:125,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('MainTest')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Test</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-210,left:200,width:110}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Assignment')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Assignments</Text>
           </TouchableOpacity> 
</View>  
      
<View style={{bottom:180,right:30,width:'100%'}}>
      <ScrollView style={stylePageWidth}> 
        
      <TouchableOpacity>
      <ImageBackground style={styles.imagebutton} source={intro1}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:23,top:6, width:107, height:27}}>Chapter 1</Text><Text style={{color:'white',fontSize:13,left:280,bottom:10,width:57,height:16}}>6 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:10,left:22}}> Introdution</Text>
    </ImageBackground>
    </TouchableOpacity>
  
    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton1} source={architecture}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:20,top:5, width:107, height:27}}>Chapter 2</Text><Text style={{color:'white',fontSize:13,left:280,bottom:10,width:57,height:16}}>14 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:13,left:22}}> Architecture</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton2} source={markov}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:20,top:10, width:107, height:27}}>Chapter 3</Text><Text style={{color:'white',fontSize:13,left:283,bottom:10,width:57,height:16}}>8 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:8,left:22}}> Markov Processes</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton3} source={simulator}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:28,top:12, width:107, height:27}}>Chapter 4</Text><Text style={{color:'white',fontSize:13,left:290,bottom:10,width:57,height:16}}>3 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:7,left:28}}> Simulation Techniques</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton4} source={standard}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:36,top:15, width:107, height:27}}>Chapter 5</Text><Text style={{color:'white',fontSize:13,left:295,bottom:10,width:57,height:16}}>6 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:5,left:37}}> Standard Interfaces</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton5} source={network}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:36,top:10, width:107, height:27}}>Chapter 6</Text><Text style={{color:'white',fontSize:13,left:295,bottom:10,width:57,height:16}}>9 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:10,left:37}}> Network Layer</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton6} source={linklayer}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:36,top:10, width:107, height:27}}>Chapter 7</Text><Text style={{color:'white',fontSize:13,left:290,bottom:10,width:57,height:16}}>16 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:10,left:37}}> Link Layer</Text>
    </ImageBackground>
    </TouchableOpacity>

    <TouchableOpacity>
      <ImageBackground style={styles.imagebutton7} source={transport}>
    <Text style={{color:'white',fontSize:22,fontWeight:'bold',left:26,top:5, width:107, height:27}}>Chapter 8</Text><Text style={{color:'white',fontSize:13,left:280,bottom:10,width:57,height:16}}>11 Pages</Text>
    <Text style={{color:'white', fontSize:14,bottom:14,left:28}}>Transport Layer (TCP/UDP)</Text>
    </ImageBackground>
    </TouchableOpacity>
   
      </ScrollView>

  
        

        </View>

          
      

      </View>
</View>

       
        </ImageBackground>
        
       

      
    
    );

 
  }
}
var styles = StyleSheet.create({

  backgroundContainer: {
    flex: 1,
    
    width:414,
    height:227,

  },

  
  header:{
    flex: 2,
    justifyContent: 'center',
    alignItems:'center',
    
  },

  uppertext:{
    color:'#FFF',
    fontSize: 22,
    
    marginRight:80,
    top:35,
  
  },

  uppertext1:{
    color:'#fff',
    fontSize: 16,
    top:38,
    marginRight:210,
  },

  menu1:{
    marginRight: 295,
    top:110,
    width:8,
  },
  menu2:{
    marginRight: 300,
    top:85,
    width:17,
  },
  menu3:{
    marginRight: 310,
    top:60,
    width:8,
  },

  adjust:{
    top: 25,
    marginLeft:290,
    transform:[{rotate: '90deg'}],
  },

  footer:{
   
    backgroundColor: 'white',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingVertical:149,
    paddingHorizontal:40,
    top:170,
  },

  imagebutton:{
    width:352,
    height:75
  },

  imagebutton1:{width:352,height:75,top:2},

  imagebutton2:{width:352,height:75,bottom:3},

  imagebutton3:{width:358,height:79,right:10,top:1},

  imagebutton4:{width:358,height:78,right:18,bottom:3},

  imagebutton5:{width:363,height:75,right:18},

  imagebutton6:{width:359,height:75,right:18},

  imagebutton7:{width:359,height:75,right:10,top:3},
  
  
  

  root:{
    flex: 1,
    flexDirection: 'column',
  },

  containerview:{
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },

 scrollView:{
   width:400,
   
 },
 red: {
  backgroundColor: '#5FAAFD',
  width:344,
  height:75,
  borderRadius:20,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  
  
},
button: {
  
 
  width:344,
  height:75,
  borderRadius:20,
  top:10,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  
  
  
}
  


  

  

});