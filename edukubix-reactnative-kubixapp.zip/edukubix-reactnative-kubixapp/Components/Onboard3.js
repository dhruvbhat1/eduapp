import * as React from 'react';
import { StyleSheet, TouchableOpacity, View, Text, Image, Dimensions } from 'react-native';
import { useFonts } from '@use-expo/font';
import { AppLoading } from 'expo';
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';


function Onboard3({ navigation }) {
  let [fontsLoaded] = useFonts({
    'Montserrat-Bold': require('../assets/fonts/Montserrat-Bold.ttf'),
    'Montserrat-Regular': require('../assets/fonts/Montserrat-Regular.ttf')
  });
  if (!fontsLoaded) {
    return <AppLoading />;
  } else {
    return (
      <View style={{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-between'
      }}>
        <View>
          <Image source={require('../images/Onboard3.jpg')} style={Dimensions.get("window").height < 700 ? styles.smallScreen : styles.bigScreen} />

        </View>




        <View>
          <View style={styles.res}>
            <Text style={{ marginTop: 30, textAlign: 'center', fontFamily: 'Montserrat-Bold', fontWeight: '500', fontSize: 20 }}>{`Practice Online Tests \n`}</Text>
            <Text style={{ lineHeight: 12, color: '#747474', marginTop: 0, textAlign: 'center', fontFamily: 'Montserrat-Regular', fontSize: 12 }}>{`Participate in multiple quizzes and exam ready with \n
ranks and reports of your performance to become a \n
master `}</Text>
          </View>

          <View >
            <FontAwesome5 style={{ marginLeft: Dimensions.get("window").height < 700 ? 110 : 159, color: '#D1D1D1', marginTop: 125, marginBottom: -6 }} name="minus" size={24} color="black" />
            <FontAwesome5 style={{ marginLeft: Dimensions.get("window").height < 700 ? 145 : 184, color: '#D1D1D1', marginTop: -20 }} name="minus" size={24} color="black" />
            <FontAwesome5 style={{ marginLeft: Dimensions.get("window").height < 700 ? 180 : 211, color: '#50B8F7', marginTop: -26 }} name="minus" size={24} color="black" />
          </View>

          <TouchableOpacity>
            <Text style={{ marginTop: -30, marginBottom: -2, marginLeft: 13, fontSize: 20, fontWeight: '900', color: '#D1D1D1', fontFamily: 'Montserrat-Regular' }}>Skip</Text>
          </TouchableOpacity>



          <TouchableOpacity
            onPress={() => navigation.navigate('Profilem')}
            style={styles.btn}>
            <AntDesign name="arrowright" style={{ marginLeft: 10, marginTop: 8 }} size={30} color="white" />
          </TouchableOpacity>

        </View>
















        {/* <Text>Onboard1</Text>

        <Button
          title="Go to Onboard2"
          onPress={() => navigation.navigate('Onboard2')}
        />
        <Button title="Go to Onboard3"
        onPress={()=>navigation.navigate('Onboard3')}/> */}
      </View>
    );
  }
}

export default Onboard3;

const styles = StyleSheet.create({
  btn: {
    backgroundColor: '#50B8F7',
    borderRadius: 50,
    height: 50,
    width: 50,
    marginLeft: Dimensions.get("window").height < 700 ? 259 : 334,
    marginBottom: 20,
    marginTop: -40
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: 30,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  bigScreen: {
    width: Dimensions.get('window').width,
    height: 300
  },
  smallScreen: {
    width: '100%',
    height: '74%'
  },
  res: {
    marginVertical: Dimensions.get("window").height < 700 ? -100 : 0
  },
  btnContent: {
    fontSize: 40,
    marginLeft: 10,
    marginTop: -5,
    color: '#ffffff'
  }
});



{/* <Text>Profile Screen</Text>
        <Button
          title="Go to Onboard2... again"
          onPress={() => navigation.push('Onboard2')}
        />
        <Button title="Onboard3" onPress={() => navigation.navigate('Onboard3')} />
        <Button title="Go back" onPress={() => navigation.goBack()} />
        <Button
          title="Go back to first screen in stack"
          onPress={() => navigation.popToTop()}
        /> */}