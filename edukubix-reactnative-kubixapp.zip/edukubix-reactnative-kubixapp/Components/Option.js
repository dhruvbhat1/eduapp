import * as React from 'react';
import { StyleSheet, Text, View, TextInput, Button, ScrollView, FlatList,Image,TouchableOpacity } from 'react-native';



function Option({navigation}) {
  return (
    <View style={styles.container}>
    
        <Image style={{marginTop:20,marginRight:350}} source={require('../images/Back.png')}/>
      
    
      <Image style={{marginTop:80}}source={require('../images/ks.png')}/>
      


      <Text style={styles.create}>Let's setup your account </Text>
      <Text style={{marginTop:10}}>Choose account type</Text>
  
      <Image style={{marginTop:20}}source={require('../images/stu.png')}/>
    

    
      <TouchableOpacity style={styles.buton} onPress={()=>navigation.navigate('Onboard1')}>
        <Text style={styles.text}>CONTINUE</Text>
        </TouchableOpacity>
      </View>
  );
}


export default Option;


const styles = StyleSheet.create({
  container:{
    flex:1,
    alignContent:"center",
    alignItems:"center",
  },
  create:{
    textAlign:'center',
    paddingTop:30,
    fontSize:25
},
clear:{
  textAlign:'center',
  fontSize:25,
},
textin:{
   borderBottomColor:'black',
   fontSize:15,
   marginTop:20,
   borderWidth:1,
   width:350,
   borderRadius:25,
   paddingHorizontal:16,
   paddingVertical:10,
   marginBottom:20
},


  buton:{
    backgroundColor:'#2a9df4',
    width:350, 
    borderRadius:25,
    paddingVertical:10,
    marginTop:20
   
  },
  text:{
    fontSize:20,
    textAlign:'center',
    paddingHorizontal:16,

    color:'#fff'
  },

});