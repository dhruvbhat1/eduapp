import React, { Component } from "react";
import { View, Text, StyleSheet, StatusBar, ImageBackground, ScrollView,Button, TouchableOpacity, SafeAreaView,Dimensions} from "react-native";
import { Entypo , Octicons, Ionicons} from '@expo/vector-icons';
import upper from '../images/upper.jpeg';
import Constants from 'expo-constants';
import { ProgressBar, Colors } from 'react-native-paper';


 const stylePageWidth ={ width:Dimensions.get('window').width};


 class Test2 extends Component{
  constructor(props) {
    super(props);
    this.state = { colorId:0 };
  }

  onPress = (id) => {
    this.setState({colorId: id});
  };


  render(){
    return(
     <View>
        <ImageBackground source={upper} style={styles.backgroundContainer}>
          
        <TouchableOpacity onPress={()=>this.props.navigation.navigate('Test1')} style={{left:20,top:20}}><Ionicons name="ios-arrow-back" size={24} color="white" /></TouchableOpacity>
          <View style={{width:280,left:40,top:30}}>

            
            
          
            
            <ProgressBar style={{backgroundColor:"white",borderRadius:20}} progress={0.2} color='#FF6F00'  styleAttr="Horizontal"/></View>
        
        <View style={{top:30}}>
       
        <View style={styles.header}>
        

        <Text style={styles.uppertext1}>Question 2/10</Text>
        <Text style={styles.uppertext}>Which is a synonym of albeit?</Text>
        

        </View>

        

<View style={styles.footer}>


{/* <Text style={{color:'#000000', fontSize:19, fontWeight:'bold',bottom:160}}>Today's Classwork</Text> */}
<View style={styles.container}>

  <View style={{bottom:10,left:30,top:20}}>
<TouchableOpacity style={this.state.colorId === 1? styles.button : styles.red}  onPress={()=>this.onPress(1)}>
        <Text style={{color:'white', fontSize:20,top:5,textAlign:"center"}}> Whether</Text>         
        
    </TouchableOpacity>
    </View>

    <View style={{bottom:10,left:30,top:35}}>
    <TouchableOpacity style={this.state.colorId === 2? styles.button : styles.red}  onPress={()=>this.onPress(2)}>
        <Text style={{color:'white', fontSize:20,top:5,textAlign:"center"}}> Although</Text>         
        
    </TouchableOpacity>
    </View>


<View style={{bottom:10,left:30,top:50}}>
    <TouchableOpacity style={this.state.colorId === 3? styles.button : styles.red}  onPress={()=>this.onPress(3)}>
        <Text style={{color:'white', fontSize:20,top:5,textAlign:"center"}}> Before</Text>         
        
    </TouchableOpacity>
    </View>

    <View style={{bottom:10,left:30,top:65}}>
    <TouchableOpacity style={this.state.colorId === 4? styles.button : styles.red}  onPress={()=>this.onPress(4)}>
        <Text style={{color:'white', fontSize:20,top:5,textAlign:"center"}}> Until</Text>         
        
    </TouchableOpacity>
 </View>
    </View>
    

  </View>

  <View style={{left:80,bottom:60}}>
    <TouchableOpacity style={this.state.colorId === 4? styles.button : styles.red}  onPress={()=>this.onPress(4)}>
        <Text style={{color:'white', fontSize:20,top:5,textAlign:"center"}}> Continue</Text>         
        
    </TouchableOpacity>
 </View>
  </View>


  
  </ImageBackground>

  <TouchableOpacity onPress={()=>this.props.navigation.navigate('Test1')} style={{top:580,left:25}}><Text style={{fontSize:19}}>Previous</Text></TouchableOpacity>
  <TouchableOpacity onPress={()=>this.props.navigation.navigate('Test2')} style={{top:555,left:290}}><Text style={{fontSize:19}}>Next</Text></TouchableOpacity>
  </View>
  
    );

 
  }
}

var styles = StyleSheet.create({

  backgroundContainer: {
    flex:1,
    width:414,
    height:350,

  },

 
  header:{
    flex:1,
    justifyContent: 'center',
    alignItems:'center',
   
  },

  uppertext:{
    color:'#FFF',
    fontSize: 26,
   
    marginRight:80,
    top:75,
    left:45
 
  },

  uppertext1:{
    color:'#fff',
    fontSize: 16,
    top:65,
    marginRight:280,
  },

  menu1:{
    marginRight: 295,
    top:110,
    width:8,
  },
  menu2:{
    marginRight: 300,
    top:85,
    width:17,
  },
  menu3:{
    marginRight: 310,
    top:60,
    width:8,
  },

  adjust:{
    top: 25,
    marginLeft:290,
    transform:[{rotate: '90deg'}],
  },

  footer:{
    backgroundColor: 'white',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingVertical:250,
    paddingHorizontal:20,
    top:250,
    width:360,
    
  },
 
 
 

  root:{
    flex: 1,
    flexDirection: 'column',
  },

  containerview:{
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },

 scrollView:{
   width:340,
   
 },
 red: {
  backgroundColor: '#5FAAFD',
  width:195,
  height:40,
  borderRadius:10,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  top:10
 
 
},
button: {
 
 
  width:195,
  height:40,
  borderRadius:10,
  top:10,
  shadowColor: '#000',
  shadowOffset: { width: 5, height: 22 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  backgroundColor:"white",
 
 
},
 



container:{
  bottom:360,
  left:30,
  
  height:270,
  width:260,
  borderRadius:10,
  borderColor:'#d3d3d3',
  borderWidth:2,
  backgroundColor:'white',
  shadowColor: 'grey',
  shadowOffset: { width: 2, height:10 },
  shadowOpacity: 0.8,
  shadowRadius: 3, 
} 

 

});
export default Test2;