import React, { Component } from 'react';
import {Platform, StyleSheet, Text, View,Image, TextInput, TouchableOpacity, ScrollView, } from 'react-native';
import { disableExpoCliLogging } from 'expo/build/logs/Logs';
import { Entypo , Octicons, Ionicons} from '@expo/vector-icons'; 

 function Teachers({ navigation }){
  
    return(
      
      <View style={styles.container}>
        
        <View style={styles.header}>
          <Octicons name="dash" size={30} color="black"  style={styles.menu1} />
          <Octicons name="dash" size={30} color="black"  style={styles.menu2}/>
          <Octicons name="dash" size={30} color="black"  style={styles.menu3}/>
          <Octicons name="settings" size={24} color="black" style={styles.adjust}/>
          <Text style={styles.uppertext}>Good Afternoon</Text>
        </View>

        <ScrollView>
        <View style={styles.footer}>
          <Text style={styles.textinsidefooter}>Hi, Dhruv!</Text>
          <Ionicons name="md-search" size={30} color="black" style={styles.search}/>
          <View style={{flexDirection:'row'}}>
           <TouchableOpacity
           onPress={() => navigation.navigate('Firstintropage')} 
           style={{backgroundColor: 'white',borderRadius: 25,paddingVertical: 10,bottom:60,width:'30%',height:26,right:10}}>
           <Text style={{fontSize:17,textAlign:'center',bottom:10,color:"#d3d3d3"}}>Home</Text>
           </TouchableOpacity> 
           <TouchableOpacity style={{backgroundColor: '#2a9df4',borderRadius: 25,paddingVertical: 10,bottom:60,width:'30%',height:26,left:5}}>
           <Text style={{fontSize:17,textAlign:'center',bottom:10,color:"white"}}>Courses</Text>
           </TouchableOpacity> 
           <TouchableOpacity style={{backgroundColor: 'white',borderRadius: 25,paddingVertical: 10,bottom:60,width:'30%',height:26,left:20}}>
           <Text style={{fontSize:17,textAlign:'center',bottom:10,color:"#d3d3d3"}}>Profile</Text>
           </TouchableOpacity> 
         </View>
          
          <View style={{right:15,bottom:20}}>
            
              <View style={{flexDirection:'row'}}>
                <TouchableOpacity onPress={() => {
                  navigation.navigate('ClassTest')
                }}>
                  <Image style={{width:171,height:171,borderRadius:15}} source={require('../images/kev.png')}/></TouchableOpacity>
                  <TouchableOpacity>
                  <Image style={{width:171,height:218,marginLeft:20}} source={require('../images/vaq.png')}/></TouchableOpacity>
              </View>

              <View style={{flexDirection:'row'}}>
                <TouchableOpacity>
                <Image style={{width:171,height:221}} source={require('../images/anj.png')}/></TouchableOpacity>
                <TouchableOpacity>
                <Image style={{width:171,height:176,marginLeft:20,marginTop:20}} source={require('../images/shra.png')}/></TouchableOpacity>
              </View>


              <View style={{flexDirection:'row'}}>
                <TouchableOpacity>
                <Image style={{width:171,height:195,borderRadius:15,marginTop:20,marginBottom:40}} source={require('../images/shin.png')}/></TouchableOpacity>
                <TouchableOpacity>
                <Image style={{width:171,height:218,marginLeft:20,borderRadius:15}} source={require('../images/shil.png')}/></TouchableOpacity>
              </View>
            
        
          </View>
        </View>
        </ScrollView>
      </View>

    )
  }


var styles = StyleSheet.create({
  container:{
    backgroundColor: '#EDF1FC',
  
  },
  header:{
    alignItems:'center',    
  },

  uppertext:{
    color:'#387FD9',
    fontSize: 21,  
    bottom:60
  },

  menu1:{
    marginRight: 295,
    top:50,
    width:8,
    
  },
  menu2:{
    marginRight: 300,
    top:25,
    width:17,
  },
  menu3:{
    marginRight: 310,
    width:8,
  },

  adjust:{
    bottom:30,
    marginLeft:290,
    transform:[{rotate: '90deg'}],
  },

  footer:{
    backgroundColor: 'white',
    borderTopLeftRadius: 50,
    borderTopRightRadius: 50,
    paddingVertical:90,
    paddingHorizontal:30,
  },

  textinsidefooter:{
    fontSize: 31,
    color:'#387FD9',
    fontWeight: "bold",
    bottom:55
  },

  search:{
    marginLeft:288,
    bottom:90,
  },

  

});
export default Teachers;