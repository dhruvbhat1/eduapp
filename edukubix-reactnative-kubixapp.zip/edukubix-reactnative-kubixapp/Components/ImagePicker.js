import React from 'react';
import { View, Button, Image, Text, Stylesheet, TouchableOpacity,state, Alert} from 'react-native';
import * as ImagePicker from 'expo-image-picker';


const ImgPicker = props => {

    const takeImageHandler = () => {
        ImagePicker.launchCameraAsync();
        
    };

    


    return (<TouchableOpacity activeOpacity={.5} >

        <Image source={require('../images/Profile.png')} />
        </TouchableOpacity>
    )


    
};


export default ImgPicker;