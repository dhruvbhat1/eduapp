import React, { Component } from "react";
import { View, Text, StyleSheet, StatusBar, ImageBackground, ScrollView,Button, TouchableOpacity, SafeAreaView,Dimensions} from "react-native";
import { Entypo , Octicons, Ionicons} from '@expo/vector-icons';
import upper from '../images/upper.jpeg';
import Constants from 'expo-constants';




 const stylePageWidth ={ width:Dimensions.get('window').width};


 class ClassTest extends Component{
  constructor(props) {
    super(props);
    this.state = { colorId:0 };
  }

  onPress = (id) => {
    this.setState({colorId: id});
  };


  render(){
    return(
     
        <ImageBackground source={upper} style={styles.backgroundContainer}>
        <View style={{top:30}}>
       
        <View style={styles.header}>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu1}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu2}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu3}/>
        <Octicons name="settings" size={24} color="#fff" style={styles.adjust}/>
        <Text style={styles.uppertext}>COMPUTER COMMUNICATION{'\n'}NETWORKS</Text>
        <Text style={styles.uppertext1}>Prof.Kevin Narohna</Text>

        </View>

        
        

<View style={styles.footer}>
<View className="col-3" style={{top:-220,right:5,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Video')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Video</Text>
           </TouchableOpacity> 
</View> 
    {/* //#2a9df4 */}

<View className="col-3"  style={{top:-250,left:70,width:70}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Notes')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Notes</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-280,left:155,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('MainTest')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Test</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-310,left:230,width:110}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Assignment')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Assignments</Text>
           </TouchableOpacity> 
</View>


<Text style={{color:'#000000', fontSize:19, fontWeight:'bold',bottom:280}}>Today's Classwork</Text>
<View style={{bottom:270,width:'100%'}}>
<ScrollView style={stylePageWidth}>
    <View style={{bottom:10,left:2,top:5}}>
    <TouchableOpacity style={this.state.colorId === 1? styles.red : styles.button}  onPress={()=>this.onPress(1)}>
        <Text style={{color:'black', fontSize:23,top:20,left:10,fontWeight:'bold'}}> CLASS TEST</Text>         
        <Text style={{fontSize:13,color:'black',left:220}}>10.30am-11.30am</Text>
        <Text style={{fontSize:17,left:20}}>Today</Text>
    </TouchableOpacity></View>
 
    <View style={{bottom:10,left:2,top:15}}>
    <TouchableOpacity style={this.state.colorId === 2? styles.red : styles.button}    onPress={()=>this.onPress(2)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 1</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 13 /08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:25,left:2}}>
    <TouchableOpacity style={this.state.colorId === 3? styles.red : styles.button}    onPress={()=>this.onPress(3)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 2</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 13 /08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:35,left:2}}>
    <TouchableOpacity style={this.state.colorId === 4? styles.red : styles.button}    onPress={()=>{
      this.onPress(4);
      this.props.navigation.navigate('Test1');}}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> CLASS TEST</Text>         
        <Text style={{fontSize:13,color:'black',left:220}}>10.30am-11.30am</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 14 /08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:45,left:2}}>
    <TouchableOpacity style={this.state.colorId === 5? styles.red : styles.button}    onPress={()=>this.onPress(5)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 3</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 15/08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:55,left:2}}>
    <TouchableOpacity style={this.state.colorId === 6? styles.red : styles.button}    onPress={()=>this.onPress(6)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 4</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 15/08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:65,left:2}}>
    <TouchableOpacity style={this.state.colorId === 7? styles.red : styles.button}    onPress={()=>this.onPress(7)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 5</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 13/08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:75,left:2}}>
    <TouchableOpacity style={this.state.colorId === 8? styles.red : styles.button}    onPress={()=>this.onPress(8)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> CLASS TEST</Text>         
        <Text style={{fontSize:13,color:'black',left:220}}>10.30am-11.30am</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 14 /08/20</Text>
    </TouchableOpacity></View>

    <View style={{bottom:10,top:85,left:2,marginBottom:110}}>
    <TouchableOpacity style={this.state.colorId === 9? styles.red : styles.button}    onPress={()=>this.onPress(9)}>
        <Text style={{color:'black', fontSize:18,top:20,left:10,fontWeight:'bold'}}> ASSIGNMENT 6</Text>         
        <Text style={{fontSize:13,color:'black',left:250}}>10 Marks</Text>
        <Text style={{fontSize:11,left:15,top:10}}>Date: 15/08/20</Text>
    </TouchableOpacity></View>
  </ScrollView>
  </View>
  </View>
  </View>
  </ImageBackground>
  
    );

 
  }
}

var styles = StyleSheet.create({

  backgroundContainer: {
    flex:1,
    width:'100%',
    height:300,

  },

 
  header:{
    flex:1,
    justifyContent: 'center',
    alignItems:'center',
   
  },

  uppertext:{
    color:'#FFF',
    fontSize: 22,
   
    marginRight:80,
    top:40,
    left:20
 
  },

  uppertext1:{
    color:'#fff',
    fontSize: 16,
    top:45,
    marginRight:210,
  },

  menu1:{
    marginRight: 295,
    top:110,
    width:8,
  },
  menu2:{
    marginRight: 300,
    top:85,
    width:17,
  },
  menu3:{
    marginRight: 310,
    top:60,
    width:8,
  },

  adjust:{
    top: 25,
    marginLeft:290,
    transform:[{rotate: '90deg'}],
  },

  footer:{
    backgroundColor: 'white',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 38,
    paddingVertical:250,
    paddingHorizontal:20,
    top:180,
    bottom:150,
    width:'100%'
    
  },
 
 
 

  root:{
    flex: 1,
    flexDirection: 'column',
  },

  containerview:{
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },

 scrollView:{
   width:'100%',
   
 },
 red: {
  backgroundColor: '#5FAAFD',
  width:'100%',
  height:100,
  borderRadius:20,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  top:10
 
 
},
button: {
  width:'100%',
  height:100,
  borderRadius:20,
  top:10,
  shadowColor: '#000',
  shadowOffset: { width: 1, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  backgroundColor:"white",
 
 
},

upvideo:{borderRadius:20,width:49,height:20},

upnotes:{borderRadius:20,width:49,height:20,left:80,bottom:20},

upass:{borderRadius:20,width:112,height:20,left:220,bottom:58},

uptest:{borderRadius:20,width:39,height:20,left:158,bottom:39},
 


 

 

});
export default ClassTest;