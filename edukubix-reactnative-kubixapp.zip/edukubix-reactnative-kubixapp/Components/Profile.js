import React, {Component} from 'react';
import { StyleSheet, Text, View,Image,TextInput,TouchableOpacity} from 'react-native';
import {render} from 'react-dom';
import * as ImagePicker from 'expo-image-picker';
import * as Expo from 'expo';


const openCam = () => {
  ImagePicker.launchCameraAsync();
  
};
const openGallery = () => {
ImagePicker.launchImageLibraryAsync();
};



function Profile({ navigation }){



      return(
        <View>
          <View>
            <Text style={styles.firstline}>Almost done!</Text>
          </View>
          <View>
            <Text style={styles.secondline}>Choose a Profile Picture</Text>
          </View>
          <View style={styles.cam} >
          <TouchableOpacity onPress={openCam}>
            <Image source={require('../images/camera.png')} style={{width:50, height:50}}/>
          </TouchableOpacity>
          </View>
          <View style={styles.gall}>
          <TouchableOpacity onPress={openGallery}>
        <Image source={require('../images/gallery.png')} style={{width:50, height:50}} />
        </TouchableOpacity>
          </View>
          <View>
            <TextInput style={styles.textinput1} placeholder="Name" underlineColorAndroid={'transparent'} />
          </View>
          <View>
            <TextInput style={styles.textinput2} placeholder="Email id" underlineColorAndroid={'transparent'} />
          </View>
          <View>
            <TouchableOpacity
            onPress={() => navigation.navigate('Teachers')}
            style={styles.button} >
              <Text style={styles.btntext}>CONTINUE</Text>
            </TouchableOpacity>
          </View>
        </View>


      )
}

   

const styles = StyleSheet.create({
    firstline:{
      fontSize:18,
      marginTop:-140,
      alignSelf:'center',
    },
    secondline:{
      fontSize:14,
      marginTop:10,
      alignItems:'center',
      color:'#7A7A7A',
      
    },
    textinput1:{
      alignSelf: 'center',
      height: 50,
      marginTop:20,
      width:'230%',
      color:'black',
      borderBottomColor: 'black',
      borderWidth: 1,
      borderRadius:25,
      textAlign:'left',
      paddingLeft:20
    },
    textinput2:{
      alignSelf: 'center',
      height: 50,
      marginTop:10,
      width:'230%',
      color:'black',
      borderBottomColor: 'black',
      borderWidth: 1,
      borderRadius:25,
      textAlign:'left',
      paddingLeft:20
    },
    button: {
      alignSelf:'center',
      height: 30,
      width:'230%',
      borderRadius:28,
      backgroundColor: '#5CACEE',
      paddingBottom:25,
      paddingTop:25,
      marginTop:15,
    },
  
    btntext: {
        color: '#fff',
        fontWeight: 'bold',
        textAlign:'center',
        marginTop:-10,
    },
    cam:{
      marginTop:10
    },
    gall:{
      marginLeft:95,
      marginTop:-50,
      
    },
    
})


export default Profile;