import * as React from 'react';
import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, } from 'react-native';

function login({ navigation }) {
  return (
    <View style={styles.container}>

      <Image style={{ marginTop: 17 }} source={require('../images/ks.png')} />


      <Text style={styles.create}>Welcome To</Text>
      <Text style={styles.clear}>KubixSquare</Text>
      <Text style={{ marginTop: 20 }}>Enter your email id to continue</Text>
      <TextInput style={styles.textin} placeholder={'Enter your Email id'}></TextInput>

      <TouchableOpacity style={styles.buton} onPress={() => navigation.navigate('Otp')}>
        <Text style={styles.text}>CONTINUE</Text>
      </TouchableOpacity>


    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignContent: "center",
    alignItems: "center",
  },
  create: {
    textAlign: 'center',
    paddingTop: 30,
    fontSize: 25
  },
  clear: {
    textAlign: 'center',
    fontSize: 25,
  },
  textin: {
    borderBottomColor: 'black',
    fontSize: 15,
    marginTop: 20,
    borderWidth: 1,
    width: '80%',
    minWidth: 300,
    borderRadius: 25,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginBottom: 20,
    textAlign: "center"
  },


  buton: {
    backgroundColor: '#2a9df4',
    width: '80%',
    minWidth: 300,
    borderRadius: 25,
    paddingVertical: 10,

  },
  text: {
    fontSize: 20,
    textAlign: 'center',
    paddingHorizontal: 16,


    color: '#fff',

  },

});


export default login;