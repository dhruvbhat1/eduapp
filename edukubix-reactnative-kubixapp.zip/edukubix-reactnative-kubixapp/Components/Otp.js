import * as React from 'react';
import { StyleSheet, Image, Text, View, TextInput, TouchableOpacity, ScrollView } from 'react-native';

function Otp({ navigation }) {

  return (
    <ScrollView >
      <View style={styles.container}>
        <Image style={{ marginTop: 17 }} source={require('../images/ks.png')} />


        <Text style={styles.create}>Welcome To</Text>
        <Text style={styles.clear}>KubixSquare</Text>
        <Text style={{ marginTop: 20, textAlign: "center" }}>{`Enter OTP sent to your Email ID \n emailaddress@gmail.com`}</Text>
        <TextInput style={styles.textin} placeholder={'Enter OTP'}></TextInput>

        <TouchableOpacity style={styles.buton} onPress={() => navigation.navigate('Details')}>
          <Text style={styles.text}>CONTINUE</Text>
        </TouchableOpacity>
        <Text style={{ textAlign: 'center', marginTop: 17, padding: 13 }}>Waiting for OTP 05:00</Text>
      </View>
    </ScrollView>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignContent: "center",
    alignItems: "center",
  },
  create: {
    textAlign: 'center',
    paddingTop: 30,
    fontSize: 25
  },
  clear: {
    textAlign: 'center',
    fontSize: 25,
  },
  textin: {
    borderBottomColor: 'black',
    fontSize: 15,
    marginTop: 20,
    borderWidth: 1,
    width: '80%',
    minWidth: 300,
    borderRadius: 25,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginBottom: 20,
    textAlign: "center"
  },


  buton: {
    backgroundColor: '#2a9df4',
    width: '80%',
    minWidth: 300,
    borderRadius: 25,
    paddingVertical: 10

  },
  text: {
    fontSize: 20,
    textAlign: 'center',
    paddingHorizontal: 16,

    color: '#fff'
  },


});

export default Otp;