import React from "react";
import { View, Text, StyleSheet, StatusBar, ImageBackground, ScrollView,Button, TouchableOpacity, SafeAreaView,Dimensions} from "react-native";

import { Entypo , Octicons, Ionicons} from '@expo/vector-icons'; 

import { Video } from 'expo-av';
import upper from '../images/upper.jpeg';
import Constants from 'expo-constants';



const stylePageWidth = { width:Dimensions.get('window').width };






 

export default class VideoPage extends React.Component{
  constructor(props) {
    super(props);
    this.state = { colorId:0 };
  }
  onPress = (id) => {
    this.setState({colorId: id});
  };
 

  
  

  render(){
    return(
     
        <ImageBackground source={upper} style={styles.backgroundContainer}>
        <View style={styles.container}>
        
        <View style={styles.header}>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu1}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu2}/>
        <Octicons name="dash" size={30} color="#fff"  style={styles.menu3}/>
        <Octicons name="settings" size={24} color="#fff" style={styles.adjust}/>
        <Text style={styles.uppertext}>COMPUTER COMMUNICATION{'\n'}NETWORKS</Text>
        <Text style={styles.uppertext1}>Prof.Kevin Narohna</Text>
 

        </View>


        <View style={styles.footer}>

        <View className="col-3" style={{top:-60,right:25,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Video')} 
           style={{backgroundColor: '#2a9df4',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"white"}}>Video</Text>
           </TouchableOpacity> 
</View> 
    {/* //#2a9df4 */}

<View className="col-3"  style={{top:-90,left:50,width:70}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Notes')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Notes</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-120,left:125,width:60}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('MainTest')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Test</Text>
           </TouchableOpacity> 
</View> 

<View className="col-3"  style={{top:-150,left:200,width:110}}> 
<TouchableOpacity
           onPress={() => this.props.navigation.navigate('Assignment')} 
           style={{backgroundColor: 'white',borderRadius: 25,height:30}}>
           <Text style={{fontSize:17,textAlign:'center',color:"#d3d3d3"}}>Assignments</Text>
           </TouchableOpacity> 
</View>  
      

<View className="col-3"  style={{top:-120,right:30,width:70}}> 
      <ScrollView style={stylePageWidth}> 
        <Video
  source={{ uri: 'http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4' }}
  rate={1.0}
  volume={1.0}
  isMuted={false}
  resizeMode="cover"
  shouldPlay={false}
  isLooping={false}
  useNativeControls
  style={{ width: 348.81, height: 184,right:30, borderRadius:20, left:2}}
/>
<Text style={{color:'#000000', fontSize:14, fontWeight:'bold'}}>Introdution </Text>
<Text style={{color:'#C0C3C8', fontSize:10}}>Data communications refers to the transmission of this digital data 
    between two or more {'\n'}computers and a computer network or data 
    network is a telecommunications network that {'\n'}allows computers to 
exchange data. The physical connection between networked comp {'\n'}
devices is established using either cable media or wireless media. 
    The best-known computer {'\n'}network is the Internet.</Text>

<Text style={{color:'#000000', fontSize:19, fontWeight:'bold'}}>Videos</Text>



      <TouchableOpacity style={this.state.colorId === 1? styles.red : styles.button}  onPress={()=>this.onPress(1)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Introdution                                                              4.30
    </Text></TouchableOpacity>
  
    <TouchableOpacity style={this.state.colorId === 2? styles.red : styles.button}    onPress={()=>this.onPress(2)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Critical Thinking                                                        4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 3? styles.red : styles.button}    onPress={()=>this.onPress(3)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Design Process                                                            4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 4? styles.red : styles.button}    onPress={()=>this.onPress(4)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Critical Thinking                                                         4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 5? styles.red : styles.button}    onPress={()=>this.onPress(5)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Design Process                                                            4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 6? styles.red : styles.button}    onPress={()=>this.onPress(6)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Critical Thinking                                                          4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 7? styles.red : styles.button}    onPress={()=>this.onPress(7)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Design Process                                                             4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 8? styles.red : styles.button}    onPress={()=>this.onPress(8)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Critical Thinking                                                          4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 9? styles.red : styles.button}    onPress={()=>this.onPress(9)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Design Process                                                              4.30
    </Text></TouchableOpacity>

    <TouchableOpacity style={this.state.colorId === 10? styles.red : styles.button}    onPress={()=>this.onPress(10)}>
    <Text style={{color:'black', fontSize:13,top:30,left:20}}> Critical Thinking                                                           4.30
    </Text></TouchableOpacity>
   
      </ScrollView>

  
        

        </View>

          
      

      </View>
</View>

       
        </ImageBackground>
        
       

      
    
    );

 
  }
}

var styles = StyleSheet.create({

  backgroundContainer: {
    flex: 1,
    
    width:414,
    height:227,

  },

  
  header:{
    flex: 2,
    justifyContent: 'center',
    alignItems:'center',
    
  },

  uppertext:{
    color:'#FFF',
    fontSize: 22,
    
    marginRight:80,
    top:35,
  
  },

  uppertext1:{
    color:'#fff',
    fontSize: 16,
    top:38,
    marginRight:210,
  },

  menu1:{
    marginRight: 295,
    top:110,
    width:8,
  },
  menu2:{
    marginRight: 300,
    top:85,
    width:17,
  },
  menu3:{
    marginRight: 310,
    top:60,
    width:8,
  },

  adjust:{
    top: 25,
    marginLeft:290,
    transform:[{rotate: '90deg'}],
  },

  footer:{
   
    backgroundColor: 'white',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingVertical:90,
    paddingHorizontal:40,
    top:150,
  },
  
  
  

  root:{
    flex: 1,
    flexDirection: 'column',
  },

  containerview:{
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },

 scrollView:{
   width:340,
   
 },
 red: {
  backgroundColor: '#5FAAFD',
  width:344,
  height:75,
  borderRadius:20,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,
  marginTop:16,
  marginBottom:-5,
  marginRight:-5,
  
},
button: {
  
 
  width:344,
  height:75,
  borderRadius:20,
  top:10,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 3,  
  elevation: 5,

  
  
}
  


  

  

});